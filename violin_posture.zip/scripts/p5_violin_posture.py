import os
import sys
import numpy as np
import matplotlib.pyplot as plt
from glob import glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROCESSED_DIR = os.path.join(ROOT, "data", "processed")
OUT_DIR = os.path.join(ROOT, "data", "output")
os.makedirs(OUT_DIR, exist_ok=True)

L_SHOULDER, R_SHOULDER = 11, 12
R_ELBOW, R_WRIST = 14, 16

FPS = 30
TILT_LIMIT = 0.05
VIOLIN_END_FRAME = 443


def elbow_angle(seq):
    a = seq[:, R_SHOULDER] - seq[:, R_ELBOW]
    b = seq[:, R_WRIST] - seq[:, R_ELBOW]
    cos = (a * b).sum(axis=1) / (np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1) + 1e-8)
    return np.degrees(np.arccos(np.clip(cos, -1, 1)))


def shoulder_tilt(seq):
    return seq[:, L_SHOULDER, 1] - seq[:, R_SHOULDER, 1]


def wrist_jitter(seq):
    w = seq[:, R_WRIST]
    acc = w[2:] - 2 * w[1:-1] + w[:-2]
    return np.linalg.norm(acc, axis=1).mean() * 100


def angle_jitter(angle):
    return np.abs(angle[2:] - 2 * angle[1:-1] + angle[:-2]).mean()


def false_alarms(tilt):
    over = np.abs(tilt) > TILT_LIMIT
    return int((over[1:] & ~over[:-1]).sum())


def analyze(base):
    results = {}
    for name in ["raw", "target", "final"]:
        path = os.path.join(PROCESSED_DIR, f"{base}_{name}.npy")
        if not os.path.exists(path):
            print(f"[skip] {path} not found")
            continue
        seq = np.load(path).astype(float)[:VIOLIN_END_FRAME]
        angle = elbow_angle(seq)
        tilt = shoulder_tilt(seq)
        results[name] = {
            "seq": seq,
            "angle": angle,
            "tilt": tilt,
            "wrist_jitter": wrist_jitter(seq),
            "angle_jitter": angle_jitter(angle),
            "tilt_std_cm": tilt.std() * 100,
            "tilt_alarms": false_alarms(tilt),
        }
    return results


def report(results):
    print("\n=== Bowing-arm posture check ===")
    print(f"{'':10s}{'wrist jitter':>14s}{'elbow angle jitter':>20s}{'shoulder tilt std(cm)':>24s}{'tilt warnings':>15s}")
    for name, r in results.items():
        print(f"{name:10s}{r['wrist_jitter']:14.2f}{r['angle_jitter']:20.2f}{r['tilt_std_cm']:24.2f}{r['tilt_alarms']:15d}")


def plot(results, base):
    fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    colors = {"raw": "#9CA3AF", "target": "#E8743B", "final": "#1F4E9E"}
    for name, r in results.items():
        t = np.arange(len(r["angle"])) / FPS
        axes[0].plot(t, r["angle"], color=colors[name], lw=2.2 if name == "final" else 1.3, label=name)
        axes[1].plot(t, r["tilt"] * 100, color=colors[name], lw=2.2 if name == "final" else 1.3, label=name)
    axes[0].set_ylabel("Right elbow angle (deg)")
    axes[1].set_ylabel("Shoulder tilt (cm)")
    axes[1].axhline(TILT_LIMIT * 100, color="#C2410C", ls="--", lw=1)
    axes[1].axhline(-TILT_LIMIT * 100, color="#C2410C", ls="--", lw=1)
    axes[1].set_xlabel("Time (s)")
    axes[0].legend(frameon=False, ncol=3)
    fig.tight_layout()
    out = os.path.join(OUT_DIR, f"{base}_posture.png")
    fig.savefig(out, dpi=200)
    print(f"\nSaved plot → {out}")


def main():
    if len(sys.argv) > 1:
        base = sys.argv[1]
    else:
        finals = sorted(glob(os.path.join(PROCESSED_DIR, "*_final.npy")), key=os.path.getmtime)
        violin = [f for f in finals if "Summer" in os.path.basename(f)]
        finals = violin or finals
        if not finals:
            print("No *_final.npy found. Run p1_2_post_processing.py first.")
            return
        base = os.path.basename(finals[-1]).replace("_final.npy", "")
    print(f"Analyzing: {base}")
    results = analyze(base)
    report(results)
    plot(results, base)


if __name__ == "__main__":
    main()