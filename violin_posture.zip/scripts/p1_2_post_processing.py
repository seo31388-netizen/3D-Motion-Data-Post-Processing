import os
import numpy as np
import pandas as pd
from glob import glob
import os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from utils.viser_test import PoseViser

RAW_KEYPOINTS_DIR = os.path.join(ROOT, "data", "raw_keypoints")
OUT_DIR = os.path.join(ROOT, "data", "processed")

os.makedirs(OUT_DIR, exist_ok=True)


def load_raw_keypoints(npz_path):
    """Load BlazePose raw data (T,33,3)."""
    data = np.load(npz_path, allow_pickle=True)["data"]
    df = pd.DataFrame(data, columns=["frame","landmark","x","y","z","visibility"])

    pts_seq = []

    for f, group in df.groupby("frame"):
        group = group.sort_values("landmark")
        pts = group[["x","y","z"]].values  # (33,3)
        pts_seq.append(pts)

    return np.array(pts_seq)   # (T,33,3)


def create_height_corrected_target(raw_seq):
    """
    raw_seq: (T,33,3)
    Return target height corrected (T,33,3)
    """

    seq = raw_seq.copy()

    # BlazePose foot joints
    LEFT_FOOT = 31
    RIGHT_FOOT = 32

    # 모든 프레임에서 발의 y값 중 최소값 → ground level
    foot_y = np.minimum(seq[:, LEFT_FOOT, 1],
                        seq[:, RIGHT_FOOT, 1])
    
    # reshape to (T,1) → broadcast to (T,33)
    frame_ground = foot_y[:, None]

    # 전체 시퀀스를 ground=0으로 맞춤
    seq[:, :, 1] -= frame_ground

    # 땅 아래(-)로 떨어지지 않게 clamp
    seq[:, :, 1] = np.maximum(seq[:, :, 1], 0)

    return seq


def smooth_motion(seq, median_win=5):
    T = seq.shape[0]
    out = seq.copy()

    p = median_win // 2
    padded = np.pad(out, ((p, p), (0, 0), (0, 0)), mode="edge")

    out = np.stack([
        np.median(padded[t:t + median_win], axis=0)
        for t in range(T)
    ])

    return seq * 0.3 + out * 0.7


LEFT_ARM = [13, 15, 17, 19, 21]
RIGHT_ARM = [14, 16, 18, 20, 22]
LEFT_LEG = [25, 27, 29, 31]
RIGHT_LEG = [26, 28, 30, 32]


def fix_left_right_swap(seq, ratio=0.5):
    out = seq.copy()
    n_fixed = 0

    for t in range(1, len(out)):
        prev = out[t - 1]
        for L, R in [(LEFT_ARM, RIGHT_ARM), (LEFT_LEG, RIGHT_LEG)]:
            keep = (np.linalg.norm(out[t, L] - prev[L], axis=1).sum()
                    + np.linalg.norm(out[t, R] - prev[R], axis=1).sum())
            swap = (np.linalg.norm(out[t, R] - prev[L], axis=1).sum()
                    + np.linalg.norm(out[t, L] - prev[R], axis=1).sum())
            if swap < keep * ratio:
                left = out[t, L].copy()
                out[t, L] = out[t, R]
                out[t, R] = left
                n_fixed += 1

    print(f"Left/right swaps fixed: {n_fixed}")
    return out


def one_euro_filter(seq, fps=30, min_cutoff=1.0,
                    beta=5.0, d_cutoff=1.0):
    def alpha(cutoff):
        tau = 1.0 / (2 * np.pi * cutoff)
        return 1.0 / (1.0 + tau * fps)

    out = np.empty_like(seq)
    out[0] = seq[0]
    dx = np.zeros_like(seq[0])

    for t in range(1, len(seq)):
        d = (seq[t] - out[t - 1]) * fps
        a_d = alpha(d_cutoff)
        dx = a_d * d + (1 - a_d) * dx
        cutoff = min_cutoff + beta * np.linalg.norm(dx, axis=-1, keepdims=True)
        a = alpha(cutoff)
        out[t] = a * seq[t] + (1 - a) * out[t - 1]

    return out


def export_unity_csv(motion, output_path):
    """
    motion: (T, 33, 3)
    Export Unity-compatible CSV.
    """

    T, n_landmarks, _ = motion.shape

    rows = []

    for t in range(T):
        for landmark in range(n_landmarks):

            x, y, z = motion[t, landmark]

            rows.append([
                t,
                landmark,
                float(x),
                float(y),
                float(z),
                1.0
            ])

    df = pd.DataFrame(
        rows,
        columns=[
            "frame",
            "landmark",
            "x",
            "y",
            "z",
            "visibility"
        ]
    )

    # 문자열 경로 처리
    output_path = os.path.abspath(output_path)

    os.makedirs(
        os.path.dirname(output_path),
        exist_ok=True
    )

    df.to_csv(
        output_path,
        index=False,
        encoding="utf-8"
    )

    print(f"Unity CSV saved: {output_path}")
    print(f"Frames: {T}")
    print(f"Landmarks: {n_landmarks}")
    print(f"Total rows: {len(df)}")


def main():
    paths = glob(f"{RAW_KEYPOINTS_DIR}/*.npz")
    print(f"Found {len(paths)} raw keypoint files")

    for path in paths:
        base = os.path.basename(path).replace(".npz", "")

        # -------------------------------
        # 1) Load raw BlazePose sequence
        # -------------------------------
        raw_seq = load_raw_keypoints(path)      # (T,33,3)
        raw_out_path = os.path.join(OUT_DIR, f"{base}_raw.npy")
        np.save(raw_out_path, raw_seq)
        print(f"Saved raw → {raw_out_path}")

        # ---------------------------------------
        # 2) Create height-corrected target (GT)
        # ---------------------------------------
        target_seq = create_height_corrected_target(raw_seq)
        target_out_path = os.path.join(OUT_DIR, f"{base}_target.npy")
        np.save(target_out_path, target_seq)
        print(f"Saved target → {target_out_path}")

        OUTPUT_PATH = (
                os.path.join(OUT_DIR,
                f"{base}_target.csv")
            )
        export_unity_csv(target_seq,OUTPUT_PATH)

        smooth_seq = smooth_motion(target_seq)
        smooth_out_path = os.path.join(OUT_DIR, f"{base}_smooth.npy")
        np.save(smooth_out_path, smooth_seq)
        print(f"Saved smooth → {smooth_out_path}")
        export_unity_csv(smooth_seq, os.path.join(OUT_DIR, f"{base}_smooth.csv"))

        fixed_seq = fix_left_right_swap(target_seq)
        final_seq = one_euro_filter(smooth_motion(fixed_seq))
        final_out_path = os.path.join(OUT_DIR, f"{base}_final.npy")
        np.save(final_out_path, final_seq)
        print(f"Saved final → {final_out_path}")
        export_unity_csv(final_seq, os.path.join(OUT_DIR, f"{base}_final.csv"))

    print("\nDone processing all keypoint files.")

    # IF you want to visualize the output
    vis = PoseViser(fps=60)
    raw = np.load(os.path.join(OUT_DIR, f"{base}_final.npy"))
    print(raw.shape)
    vis.play_sequence(raw)


if __name__ == "__main__":
    main()