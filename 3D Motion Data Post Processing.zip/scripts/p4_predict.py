
from pathlib import Path
import sys
import json

import numpy as np
import pandas as pd
import torch
import os

ROOT = Path(__file__).resolve().parent.parent

# 프로젝트 루트와 scripts 폴더 등록
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from utils.viser_test import PoseViser
from importlib import import_module

# Import the same model used during training
ActionMLP = import_module("p3_train_mlp").ActionMLP

MODEL_PATH = ROOT / "checkpoints" / "best_mlp.pth"
LABEL_PATH = ROOT / "data" / "dataset" / "labels.json"

# Change this to the keypoint file you want to test
INPUT_PATH = ROOT / "data" / "test_keypoints" / "forehand" / "Fonseca_side_view_practice_session.npz"

SEQ_LENGTH = 30
STRIDE = 15


def load_raw_keypoints(npz_path):
    """Load MediaPipe keypoints: (T, 33, 3)."""

    data = np.load(npz_path, allow_pickle=True)["data"]

    df = pd.DataFrame(
        data,
        columns=["frame", "landmark", "x", "y", "z", "visibility"]
    )

    frames = []

    for _, group in df.groupby("frame"):
        group = group.sort_values("landmark")
        points = group[["x", "y", "z"]].to_numpy(dtype=np.float32)

        if points.shape == (33, 3):
            frames.append(points)

    return np.asarray(frames, dtype=np.float32)


def create_sequences(motion):
    """Convert (T, 33, 3) to (N, 30, 99)."""

    sequences = []

    for start in range(0, len(motion) - SEQ_LENGTH + 1, STRIDE):
        clip = motion[start:start + SEQ_LENGTH]
        sequences.append(clip.reshape(SEQ_LENGTH, 99))

    if not sequences:
        raise ValueError("Video is shorter than 30 detected frames.")

    return np.asarray(sequences, dtype=np.float32)

def export_unity_csv(motion, output_path):
    """
    motion: (T, 33, 3)
    output: Unity-compatible CSV
    """
    rows = []

    T, n_bones, _ = motion.shape

    for t in range(T):
        for b in range(n_bones):
            x, y, z = motion[t, b]
            rows.append([t, b, x, y, z, 1.0])

    df = pd.DataFrame(
        rows,
        columns=[
            "frame", "landmark",
            "x", "y", "z", "visibility"
        ]
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)

    print(f"Unity CSV saved: {output_path}")

def main():
    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    # Load class labels
    with open(LABEL_PATH, "r", encoding="utf-8") as f:
        labels = json.load(f)

    id_to_label = {v: k for k, v in labels.items()}

    # Load trained model
    model = ActionMLP(num_classes=len(labels)).to(device)
    model.load_state_dict(
        torch.load(MODEL_PATH, map_location=device, weights_only=True)
    )
    model.eval()

    # Load and prepare input
    motion = load_raw_keypoints(INPUT_PATH)
    sequences = create_sequences(motion)

    X = torch.from_numpy(sequences).to(device)

    # Predict
    with torch.no_grad():
        logits = model(X)
        probabilities = torch.softmax(logits, dim=1)

    # Average probabilities across all windows
    avg_probabilities = probabilities.mean(dim=0)

    predicted_id = avg_probabilities.argmax().item()
    predicted_label = id_to_label[predicted_id]

    print(f"\nInput: {INPUT_PATH.name}")
    print(f"Frames: {len(motion)}")
    print(f"Sequences: {len(sequences)}")

    print("\nPrediction probabilities:")
    for i, probability in enumerate(avg_probabilities):
        print(f"  {id_to_label[i]}: {probability.item():.4f}")

    print(f"\nPredicted action: {predicted_label}")


    # Export keypoints for Unity
    OUTPUT_PATH = (
        ROOT / "data" / "output" /
        f"{INPUT_PATH.stem}_{predicted_label}.csv"
    )

    export_unity_csv(motion, OUTPUT_PATH)

    vis = PoseViser(fps=30)

    vis.server.gui.add_text(
        "Predicted Action",
        initial_value=predicted_label,
        disabled=True
    )

    vis.server.gui.add_number(
        "Confidence",
        initial_value=float(avg_probabilities[predicted_id].item()),
        disabled=True
    )

    vis.play_sequence(motion)


if __name__ == "__main__":
    main()
